# Premium Project — Guest Attendance System

Website absensi tamu berbasis GitHub Pages + Google Sheets + Google Apps Script.

## Struktur
- `index.html` — shell website
- `style.css` — desain responsive Desktop / Tablet / HP
- `app.js` — navigasi, pencarian, Check In, Check Out, dashboard, export
- `Code.gs` — backend Google Apps Script
- `README.md` — panduan

## Demo Mode
Website langsung bisa dibuka tanpa Google Sheets. Data demo tersimpan sementara di browser.

## Hubungkan Google Sheets
1. Buat Google Sheet.
2. Buat sheet `MASTER TAMU` dengan header:
   `ID | NAMA | TAMU DARI | KETERANGAN | UNDANGAN`
3. Buat sheet `ABSENSI` dengan header:
   `ID | TIMESTAMP | TANGGAL | JAM | AKSI | NAMA | TAMU DARI | KETERANGAN | UNDANGAN | SUMBER`
4. Buka Extensions > Apps Script.
5. Salin isi `Code.gs`.
6. Deploy > New deployment > Web app.
7. Execute as: Me.
8. Who has access: Anyone.
9. Copy URL `/exec`.
10. Buka `app.js`, isi `GOOGLE_APPS_SCRIPT_URL` dengan URL tersebut.
11. Commit perubahan ke GitHub.

Catatan: untuk produksi, sebaiknya tambahkan validasi, autentikasi operator, dan pembatasan rate agar endpoint tidak disalahgunakan.
